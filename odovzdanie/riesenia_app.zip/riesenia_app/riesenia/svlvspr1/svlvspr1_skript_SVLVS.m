k1 = -2;
k2 = -4;
r = 1;
r1 = 0.5;
rv = [1,-1,pi];
rvpid = [1,-1,0];
time = 15;

r = pi;
rpid = 1;
P = 9;
I = 6;
D = 4;